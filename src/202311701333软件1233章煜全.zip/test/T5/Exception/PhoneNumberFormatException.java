package test.T5.Exception;

public class PhoneNumberFormatException extends RuntimeException{
}
