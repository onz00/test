package test.T5.Exception;

public class QQFormatException extends RuntimeException{
}
